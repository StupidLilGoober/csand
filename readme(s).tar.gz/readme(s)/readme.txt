                      CSAND
  CSand (pronounced 'sand') is an open-source 
  software meant to imitate the way sand moves
  in real life.

  It also boasts 10+ other elements and a
  relaxing soundtrack by Benjamin "Ambailgail"
  Sauter, and other features.

  It is developed and maintained primarily by
  Dominic Kolp, as a small side-project.

  He is making this to prepare for what the video
  games industry is truly like.
  **********************************************
  Dominic Kolp, 2025