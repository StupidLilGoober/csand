CSAND
*** copyright <c> Dominic ("Dom") Kolp ***
Pronounced "sand"

*** keyboard commands ***
1      | sand
2      | wall
3      | water
4      | acid
e      | eraser tool
s      | spray tool
p      | pencil tool
r      | restart
f11    | fullscreen
alt-f4 | quit
esc    | pause

*** mouse commands ***
pgup   | increase brush size
pgdn   | decrease brush size
ms1    | use current tool
ms2    | use eraser tool

*** other ***
https://github.com/stupidlilgoober/csand
read 'license'
read 'contributing'
